from django.urls import reverse
from django.db import models
from django.contrib.auth.models import User
from attendance.models import TimeLog

class Employee(models.Model):
    ROLE_CHOICES = [
        ('Admin', 'Admin'),
        ('Manager', 'Manager'),
        ('Staff', 'Staff'),
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE)
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=15)
    department = models.CharField(max_length=100)
    hire_date = models.DateField()
    salary = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.BooleanField(default=True)
    role = models.CharField(max_length=20, choices=ROLE_CHOICES)
    position = models.CharField(max_length=100, default='Staff')  # Set a default value here
    hourly_rate = models.DecimalField(max_digits=10, decimal_places=2, default=15.00)  # Set a default value here
    work_hours = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)  # Work hours in decimal form


    def __str__(self):
        return f"{self.first_name} {self.last_name}"

    def calculate_daily_salary(self):
        try:
            total_hours = TimeLog.total_hours_today(self.user)  # Pass user, not self
            if total_hours is None:
                total_hours = 0
            return total_hours * self.hourly_rate
        except Exception as e:
            print(f"Error calculating daily salary: {e}")
            return 0  # Default to 0 if there's an error

    def calculate_monthly_salary(self):
        try:
            total_hours = TimeLog.total_hours_this_month(self.user)
            if total_hours is None:
                total_hours = 0
            return total_hours * self.hourly_rate
        except Exception as e:
            print(f"Error calculating monthly salary: {e}")
            return 0  # Default to 0 if there's an error

    def __str__(self):
        return f"{self.user.first_name} {self.user.last_name}"

