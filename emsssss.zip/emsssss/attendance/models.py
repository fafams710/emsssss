from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class Attendance(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    time_in = models.DateTimeField(null=True, blank=True)
    time_out = models.DateTimeField(null=True, blank=True)
    date = models.DateField(default=timezone.now)
    hourly_rate = models.DecimalField(max_digits=10, decimal_places=2, default=15.00)
    work_hours = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)


class AuthCode(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    code = models.CharField(max_length=6)
    is_active = models.BooleanField(default=True)  # Add is_active field
    created_at = models.DateTimeField(auto_now_add=True)  # Add created_at field

    def __str__(self):
        return f'{self.user.username} - {self.code}'

class TimeLog(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    time_in = models.DateTimeField(null=True, blank=True)
    time_out = models.DateTimeField(null=True, blank=True)

    def hours_worked(self):
        if self.time_in and self.time_out:
            return (self.time_out - self.time_in).total_seconds() / 3600
        return 0.0

    @classmethod
    def total_hours_today(cls, user):
        today = timezone.now().date()
        time_logs = cls.objects.filter(user=user, time_in__date=today)
        total_hours = sum(log.hours_worked() for log in time_logs)
        return total_hours

    @classmethod
    def total_hours_this_month(cls, user):
        now = timezone.now()
        first_day_of_month = now.replace(day=1)
        time_logs = cls.objects.filter(user=user, time_in__gte=first_day_of_month)
        total_hours = sum(log.hours_worked() for log in time_logs)
        return total_hours