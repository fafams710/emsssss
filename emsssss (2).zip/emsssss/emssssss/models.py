#main app toh wag gagalawin
from django.db import models

# Create your models here.
